package jeudecarac;

/**
 * Classe principale
 * @author Roussel - Heinrich
 */
public class Main {

    public static void main(String[] args) {

        //mets la fenetre dans la queue d'actions de l'EventDispatchThread
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });


    }
}
